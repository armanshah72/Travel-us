export interface State {
  id: number;
  name: string;
  description: string;
  image: string;
  attractions: Attraction[];
}

export interface Attraction {
  id: number;
  name: string;
  description: string;
  image: string;
  location: string;
}

export const states: State[] = [
  {
    id: 1,
    name: "Uttar Pradesh",
    description: "Home to the iconic Taj Mahal and rich cultural heritage",
    image: "https://images.unsplash.com/photo-1552618964-d82464bde956",
    attractions: [
      {
        id: 1,
        name: "Taj Mahal",
        description: "An iconic symbol of love built by Shah Jahan",
        image: "https://images.unsplash.com/photo-1736238292739-861f798fa879",
        location: "Agra"
      }
    ]
  },
  {
    id: 2,
    name: "Rajasthan",
    description: "Land of kings, palaces, and vibrant culture",
    image: "https://images.unsplash.com/photo-1628490238189-4fc2b6b4ca3b",
    attractions: [
      {
        id: 2,
        name: "Hawa Mahal",
        description: "Palace of Winds, a unique architectural marvel",
        image: "https://images.unsplash.com/photo-1659692917561-76f375dc418c",
        location: "Jaipur"
      }
    ]
  },
  {
    id: 3,
    name: "Kerala",
    description: "God's own country with serene backwaters",
    image: "https://images.unsplash.com/photo-1735709546649-674bbc3b6619",
    attractions: [
      {
        id: 3,
        name: "Backwaters",
        description: "Tranquil waterways surrounded by lush greenery",
        image: "https://images.unsplash.com/photo-1659692917321-175433780bec",
        location: "Alleppey"
      }
    ]
  }
];

export const culturalImages = [
  "https://images.unsplash.com/photo-1511164657592-59a452023479",
  "https://images.unsplash.com/photo-1622279486466-e0e3bfdd0a01",
  "https://images.unsplash.com/photo-1622279488670-123d0fd161cb",
  "https://images.unsplash.com/photo-1622279488885-d831e8e76cef"
];

export const galleryImages = [
  "https://images.unsplash.com/photo-1736238292739-861f798fa879",
  "https://images.unsplash.com/photo-1736238290763-60998fbcd048",
  "https://images.unsplash.com/photo-1736238292658-500c6727172b",
  "https://images.unsplash.com/photo-1736237619962-a8356a833825",
  "https://images.unsplash.com/photo-1628490238189-4fc2b6b4ca3b",
  "https://images.unsplash.com/photo-1552618964-d82464bde956"
];
