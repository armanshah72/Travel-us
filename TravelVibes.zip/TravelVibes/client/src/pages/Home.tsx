import Header from "@/components/Header";
import Hero from "@/components/Hero";
import StateGrid from "@/components/StateGrid";
import Gallery from "@/components/Gallery";
import BookingForm from "@/components/BookingForm";
import ContactForm from "@/components/ContactForm";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <Hero />
        <StateGrid />
        <Gallery />
        <BookingForm />
        <ContactForm />
      </main>
      <Footer />
    </div>
  );
}
