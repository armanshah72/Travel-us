import { Facebook, Instagram, Twitter } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-background border-t">
      <div className="container px-4 py-12 mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-lg font-semibold mb-4">Incredible India</h3>
            <p className="text-sm text-muted-foreground">
              Discover the beauty and diversity of India's rich cultural heritage.
            </p>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-sm hover:text-primary">Home</a>
              </li>
              <li>
                <a href="#states" className="text-sm hover:text-primary">States</a>
              </li>
              <li>
                <a href="#gallery" className="text-sm hover:text-primary">Gallery</a>
              </li>
              <li>
                <a href="#contact" className="text-sm hover:text-primary">Contact</a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Info</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>Email: travelwithus@gmail.com</li>
              <li>Instagram: @explore_india</li>
              <li>Website: www.travelwithindia.com</li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Follow Us</h3>
            <div className="flex space-x-4">
              <a href="#" className="hover:text-primary">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="hover:text-primary">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="hover:text-primary">
                <Twitter className="h-5 w-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t text-center text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} Incredible India. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
