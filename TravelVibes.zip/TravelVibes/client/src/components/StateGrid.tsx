import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { states, type State, type Attraction } from "@/data/destinations";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export default function StateGrid() {
  const [selectedState, setSelectedState] = useState<State | null>(null);

  return (
    <section id="states" className="py-24 states-section">
      <div className="container px-4 mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold mb-4">Explore Indian States</h2>
          <p className="text-muted-foreground">
            Discover the diverse beauty and culture of India's most iconic states
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {states.map((state) => (
            <motion.div
              key={state.id}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              whileHover={{ scale: 1.02 }}
              transition={{ duration: 0.2 }}
            >
              <Card
                className="cursor-pointer overflow-hidden"
                onClick={() => setSelectedState(state)}
              >
                <div className="relative h-64">
                  <img
                    src={state.image}
                    alt={state.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/40 flex items-end p-6">
                    <div>
                      <h3 className="text-xl font-bold text-white mb-2">{state.name}</h3>
                      <p className="text-white/90">{state.description}</p>
                    </div>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>

        <Dialog open={!!selectedState} onOpenChange={() => setSelectedState(null)}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>{selectedState?.name}</DialogTitle>
            </DialogHeader>
            <div className="grid gap-6">
              {selectedState?.attractions.map((attraction: Attraction) => (
                <div key={attraction.id} className="space-y-4">
                  <img
                    src={attraction.image}
                    alt={attraction.name}
                    className="w-full h-64 object-cover rounded-lg"
                  />
                  <div>
                    <h4 className="text-xl font-bold mb-2">{attraction.name}</h4>
                    <p className="text-muted-foreground mb-2">{attraction.description}</p>
                    <p className="text-sm">📍 {attraction.location}</p>
                  </div>
                </div>
              ))}
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </section>
  );
}