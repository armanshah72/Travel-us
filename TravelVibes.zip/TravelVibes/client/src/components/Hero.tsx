import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

export default function Hero() {
  return (
    <div className="relative h-screen hero-section">
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1736238292739-861f798fa879")'
        }}
      >
        <div className="absolute inset-0 bg-black/50" />
      </div>

      <div className="relative h-full flex items-center justify-center text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-3xl px-6"
        >
          <h1 className="text-4xl sm:text-6xl font-bold text-white mb-6">
            Discover the Wonders of India
          </h1>
          <p className="text-lg sm:text-xl text-white/90 mb-8">
            Experience the rich culture, ancient traditions, and breathtaking landscapes
          </p>
          <Button
            size="lg"
            className="group"
            onClick={() => document.getElementById('states')?.scrollIntoView({ behavior: 'smooth' })}
          >
            Start Your Journey
            <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
          </Button>
        </motion.div>
      </div>
    </div>
  );
}